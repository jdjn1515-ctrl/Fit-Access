#!/bin/bash

# Fit Access - Quick Deploy Script
# This script automates deployment to GitHub Pages

set -e  # Exit on error

echo "🚀 Fit Access - Quick Deploy Script"
echo "===================================="
echo ""

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "❌ Error: git is not installed"
    echo "Install git: https://git-scm.com/downloads"
    exit 1
fi

# Get GitHub username
echo "📝 Setting up GitHub deployment..."
read -p "Enter your GitHub username: " GITHUB_USER

if [ -z "$GITHUB_USER" ]; then
    echo "❌ Error: GitHub username is required"
    exit 1
fi

# Get repository name (default: fit-access)
read -p "Enter repository name (default: fit-access): " REPO_NAME
REPO_NAME=${REPO_NAME:-fit-access}

echo ""
echo "📦 Configuration:"
echo "   GitHub User: $GITHUB_USER"
echo "   Repository: $REPO_NAME"
echo "   URL: https://$GITHUB_USER.github.io/$REPO_NAME/"
echo ""
read -p "Continue? (y/n) " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ Deployment cancelled"
    exit 1
fi

# Initialize git if not already
if [ ! -d .git ]; then
    echo "🔧 Initializing git repository..."
    git init
    echo "✓ Git initialized"
fi

# Add all files
echo "📁 Adding files to git..."
git add .

# Create commit
echo "💾 Creating commit..."
git commit -m "Initial commit: Fit Access MVP" || echo "No changes to commit"

# Rename branch to main if needed
CURRENT_BRANCH=$(git branch --show-current)
if [ "$CURRENT_BRANCH" != "main" ]; then
    echo "🔄 Renaming branch to main..."
    git branch -M main
fi

# Add remote
echo "🔗 Adding GitHub remote..."
git remote remove origin 2>/dev/null || true
git remote add origin "https://github.com/$GITHUB_USER/$REPO_NAME.git"

# Push to GitHub
echo "⬆️  Pushing to GitHub..."
echo ""
echo "⚠️  You'll need to create the repository on GitHub first:"
echo "   1. Go to: https://github.com/new"
echo "   2. Repository name: $REPO_NAME"
echo "   3. Make it Public"
echo "   4. Don't initialize with README"
echo "   5. Click 'Create repository'"
echo ""
read -p "Have you created the repository? (y/n) " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ Please create the repository first, then run this script again"
    exit 1
fi

# Push to GitHub
git push -u origin main

echo ""
echo "✅ Code pushed to GitHub!"
echo ""
echo "📄 Next steps:"
echo "   1. Go to: https://github.com/$GITHUB_USER/$REPO_NAME/settings/pages"
echo "   2. Under 'Source', select: Deploy from branch 'main' → '/' (root)"
echo "   3. Click 'Save'"
echo "   4. Wait 2-3 minutes for deployment"
echo ""
echo "🌐 Your site will be live at:"
echo "   https://$GITHUB_USER.github.io/$REPO_NAME/"
echo ""
echo "🎉 Deployment complete!"
echo ""
echo "📱 Test the app:"
echo "   Landing: https://$GITHUB_USER.github.io/$REPO_NAME/"
echo "   App Demo: https://$GITHUB_USER.github.io/$REPO_NAME/fit-access-app.html"
echo ""
