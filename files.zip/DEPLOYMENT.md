# Fit Access - Deployment Guide

Complete instructions for deploying Fit Access to various platforms.

## 📦 What You're Deploying

- **Landing Page** (`index.html`) - Marketing site
- **Mobile App Demo** (`fit-access-app.html`) - Fully functional web app
- **Documentation** (`README.md`, `API_DOCS.md`, etc.)

## 🚀 Quick Deploy Options

### Option 1: GitHub Pages (Recommended for Demo)

**Pros:** Free, fast, automatic HTTPS, custom domain support  
**Cons:** Static hosting only (no backend)

**Steps:**

1. **Create GitHub Repository**
```bash
# Initialize git in your project folder
git init
git add .
git commit -m "Initial commit: Fit Access MVP"

# Create repo on GitHub, then:
git remote add origin https://github.com/YOUR-USERNAME/fit-access.git
git branch -M main
git push -u origin main
```

2. **Enable GitHub Pages**
   - Go to repository Settings → Pages
   - Source: Deploy from branch `main` → `/` (root)
   - Save
   - Your site will be live at: `https://YOUR-USERNAME.github.io/fit-access/`

3. **Custom Domain (Optional)**
   - Add `CNAME` file with your domain: `fitaccess.yourdomain.com`
   - Update DNS: Add CNAME record pointing to `YOUR-USERNAME.github.io`
   - Enable HTTPS in GitHub Pages settings

**Files to deploy:**
```
fit-access/
├── index.html              # Landing page
├── fit-access-app.html     # App demo
├── README.md
└── docs/                   # All documentation
```

**Live in:** ~2 minutes  
**URL:** `https://YOUR-USERNAME.github.io/fit-access/`

---

### Option 2: Vercel (Recommended for Production)

**Pros:** Instant deploys, serverless functions, preview URLs, analytics  
**Cons:** Requires account (free tier available)

**Steps:**

1. **Install Vercel CLI**
```bash
npm i -g vercel
```

2. **Deploy**
```bash
cd fit-access
vercel

# Follow prompts:
# - Set up and deploy? Yes
# - Scope: Your account
# - Link to existing project? No
# - Project name: fit-access
# - Directory: ./
# - Override settings? No
```

3. **Production Deployment**
```bash
vercel --prod
```

4. **Custom Domain**
```bash
vercel domains add fitaccess.app
# Follow DNS instructions
```

**Live in:** ~30 seconds  
**URL:** `https://fit-access.vercel.app` (or your custom domain)

---

### Option 3: Netlify

**Pros:** Easy drag-and-drop, form handling, split testing  
**Cons:** Fewer serverless features than Vercel

**Steps:**

1. **Via Web Interface**
   - Go to [netlify.com](https://netlify.com)
   - Drag and drop your `fit-access` folder
   - Site is live immediately

2. **Via CLI**
```bash
npm i -g netlify-cli
netlify deploy

# For production:
netlify deploy --prod
```

3. **Custom Domain**
   - Site settings → Domain management → Add custom domain
   - Update DNS as instructed

**Live in:** ~30 seconds  
**URL:** `https://fit-access.netlify.app`

---

### Option 4: Self-Hosted (VPS/AWS/GCP)

**Pros:** Full control, can add backend  
**Cons:** Requires server management

**Using NGINX:**

```bash
# Install NGINX
sudo apt update
sudo apt install nginx

# Copy files
sudo mkdir -p /var/www/fitaccess
sudo cp -r fit-access/* /var/www/fitaccess/

# Configure NGINX
sudo nano /etc/nginx/sites-available/fitaccess
```

**NGINX Config:**
```nginx
server {
    listen 80;
    server_name fitaccess.app www.fitaccess.app;
    root /var/www/fitaccess;
    index index.html;

    location / {
        try_files $uri $uri/ =404;
    }

    # Gzip compression
    gzip on;
    gzip_types text/css application/javascript image/svg+xml;
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/fitaccess /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

# Install SSL with Let's Encrypt
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d fitaccess.app -d www.fitaccess.app
```

**Live in:** ~10 minutes  
**Cost:** $5-20/month (VPS)

---

## 📱 Native Mobile App Deployment

### iOS App Store

**Prerequisites:**
- Apple Developer Account ($99/year)
- Mac with Xcode
- React Native app (conversion from web demo)

**Steps:**

1. **Convert to React Native**
   - Follow implementation plan in `API_DOCS.md`
   - Use Expo or React Native CLI

2. **Build with Expo (Easier)**
```bash
# Install Expo CLI
npm install -g expo-cli eas-cli

# Create Expo project
expo init FitAccessApp
# Copy code from web demo, adapt to React Native

# Build for iOS
eas build --platform ios
```

3. **Submit to App Store**
```bash
eas submit --platform ios
```

4. **Review Process**
   - Apple reviews app (1-3 days)
   - Once approved, live on App Store

**Timeline:** 2-3 weeks (including conversion)  
**Cost:** $99/year

---

### Google Play Store

**Prerequisites:**
- Google Play Developer Account ($25 one-time)
- Android Studio (or Expo)

**Steps:**

1. **Build APK/AAB**
```bash
# With Expo
eas build --platform android

# Or with React Native CLI
cd android
./gradlew assembleRelease
```

2. **Submit to Play Store**
   - Create app in Play Console
   - Upload AAB file
   - Fill out store listing
   - Submit for review

**Timeline:** 1-2 weeks  
**Cost:** $25 one-time

---

## 🔧 Backend Deployment (Supabase)

**For production with real authentication and database:**

1. **Create Supabase Project**
   - Go to [supabase.com](https://supabase.com)
   - Create new project
   - Note your API URL and anon key

2. **Set Up Database**
```sql
-- Run the schema from API_DOCS.md
-- Create tables: users, memberships, facilities, etc.
```

3. **Deploy Edge Functions**
```bash
# Install Supabase CLI
npm i supabase -g

# Login
supabase login

# Link project
supabase link --project-ref YOUR_PROJECT_REF

# Deploy functions
supabase functions deploy qr-token-generate
supabase functions deploy entry-validate
```

4. **Update App Config**
```javascript
// In fit-access-app.html, add:
const SUPABASE_URL = 'https://YOUR_PROJECT.supabase.co'
const SUPABASE_ANON_KEY = 'your-anon-key'
```

**Cost:** Free tier (50K MAU), then $25/month

---

## 🌐 CDN Configuration (Optional)

**For faster global delivery:**

### Cloudflare (Free)

1. Sign up at [cloudflare.com](https://cloudflare.com)
2. Add your domain
3. Update nameservers as instructed
4. Enable:
   - Auto Minify (CSS, JS, HTML)
   - Brotli compression
   - Browser Cache TTL: 4 hours
   - Always Use HTTPS

**Performance gain:** 30-50% faster load times

---

## 📊 Analytics Setup (Optional)

### PostHog (Privacy-Friendly)

```html
<!-- Add to both index.html and fit-access-app.html -->
<script>
!function(t,e){var o,n,p,r;e.__SV||(window.posthog=e,e._i=[],e.init=function(i,s,a){function g(t,e){var o=e.split(".");2==o.length&&(t=t[o[0]],e=o[1]),t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}}(p=t.createElement("script")).type="text/javascript",p.async=!0,p.src=s.api_host+"/static/array.js",(r=t.getElementsByTagName("script")[0]).parentNode.insertBefore(p,r);var u=e;for(void 0!==a?u=e[a]=[]:a="posthog",u.people=u.people||[],u.toString=function(t){var e="posthog";return"posthog"!==a&&(e+="."+a),t||(e+=" (stub)"),e},u.people.toString=function(){return u.toString(1)+".people (stub)"},o="capture identify alias people.set people.set_once set_config register register_once unregister opt_out_capturing has_opted_out_capturing opt_in_capturing reset isFeatureEnabled onFeatureFlags getFeatureFlag getFeatureFlagPayload reloadFeatureFlags group updateEarlyAccessFeatureEnrollment getEarlyAccessFeatures getActiveMatchingSurveys getSurveys".split(" "),n=0;n<o.length;n++)g(u,o[n]);e._i.push([i,s,a])},e.__SV=1)}(document,window.posthog||[]);
posthog.init('YOUR_API_KEY',{api_host:'https://app.posthog.com'})
</script>
```

**Track:**
- Page views
- QR code generations
- Entry attempts
- Signup funnel

---

## ✅ Pre-Launch Checklist

### Performance
- [ ] Images optimized (use WebP, lazy loading)
- [ ] CSS/JS minified
- [ ] Gzip/Brotli enabled
- [ ] Font loading optimized
- [ ] Lighthouse score >90

### Security
- [ ] HTTPS enabled
- [ ] CSP headers configured
- [ ] XSS protection headers
- [ ] CORS properly configured
- [ ] No hardcoded secrets

### SEO
- [ ] Meta tags (title, description)
- [ ] Open Graph tags (for social sharing)
- [ ] Sitemap.xml
- [ ] Robots.txt
- [ ] Google Search Console verified

### Legal
- [ ] Privacy policy live
- [ ] Terms of service live
- [ ] Cookie consent (if using analytics)
- [ ] GDPR compliance verified
- [ ] Contact information visible

---

## 🚨 Troubleshooting

### GitHub Pages Not Loading

**Issue:** 404 on custom domain  
**Fix:** Check `CNAME` file exists, DNS propagated (24-48 hrs)

**Issue:** Styles not loading  
**Fix:** Use relative paths (`./style.css` not `/style.css`)

### Vercel Build Failing

**Issue:** "No output directory"  
**Fix:** Vercel auto-detects static sites, should work. Check build logs.

### SSL Certificate Errors

**Issue:** "Not secure" warning  
**Fix:** Wait for SSL to provision (5-30 min) or renew with `certbot renew`

---

## 📈 Monitoring

### Uptime Monitoring (Free)

**UptimeRobot:** [uptimerobot.com](https://uptimerobot.com)
- Add your URL
- Get alerts if site goes down
- 50 monitors free

### Performance Monitoring

**Google Lighthouse CI:**
```bash
npm install -g @lhci/cli
lhci autorun --upload.target=temporary-public-storage
```

---

## 🎯 Next Steps After Deploy

1. **Share the demo:** Tweet, LinkedIn, Reddit
2. **Get feedback:** User testing with real gym members
3. **Add analytics:** Track which features are used most
4. **Build backend:** Convert to full production app with Supabase
5. **Convert to native:** React Native for App Store/Play Store

---

## 💬 Support

- **Issues:** [GitHub Issues](https://github.com/YOUR-USERNAME/fit-access/issues)
- **Email:** deploy@fitaccess.app
- **Docs:** [Full documentation](README.md)

**Your app is ready to publish! Choose a deployment option above and go live in minutes.** 🚀
